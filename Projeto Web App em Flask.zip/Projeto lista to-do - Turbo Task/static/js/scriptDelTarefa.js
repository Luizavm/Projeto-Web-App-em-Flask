// Script simplificado para manipular a seleção e exibir o modal 
document.addEventListener('DOMContentLoaded', function() { // Aguarda o carregamento completo do DOM
    const checkboxes = document.querySelectorAll('.task-checkbox'); // Seleciona todos os checkboxes das tarefas
    const deleteBtn = document.getElementById('deleteSelectedBtn'); // Botão de "Excluir selecionados"
    const modal = document.getElementById('confirmModal'); // Modal de confirmação de exclusão
    const cancelBtn = document.getElementById('cancelDelete'); // Botão para cancelar a exclusão
    const form = document.getElementById('deleteForm'); // Formulário de exclusão que será enviado

    // Atualizar estado do botão de exclusão (ativa/desativa conforme seleção)
    function updateDeleteButton() {
        const hasSelected = Array.from(checkboxes).some(cb => cb.checked); // Verifica se algum checkbox está marcado
        deleteBtn.disabled = !hasSelected; // Habilita ou desabilita o botão
    }

    // Adiciona listeners a todos os checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateDeleteButton); // Atualiza botão ao marcar/desmarcar

        // Destaca visualmente o card selecionado
        checkbox.addEventListener('change', function() {
            const card = this.closest('.task-card'); // Encontra o card da tarefa mais próximo do checkbox

            if (this.checked) {
                card.classList.add('selected'); // Adiciona classe se estiver marcado
            } else {
                card.classList.remove('selected'); // Remove a classe se desmarcado
            }
        });
    });

    // Exibe o modal de confirmação ao clicar no botão de exclusão
    deleteBtn.addEventListener('click', function() {
        if (!deleteBtn.disabled) {
            modal.style.display = 'flex'; // Mostra o modal com flexbox
        }
    });

    // Fecha o modal ao clicar no botão "Cancelar"
    cancelBtn.addEventListener('click', function() {
        modal.style.display = 'none'; // Esconde o modal
    });

    // Fecha o modal ao clicar fora do conteúdo do modal
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none'; // Fecha o modal se clicar fora dele
        }
    });

    // Esconde automaticamente as mensagens flash após 5 segundos
    setTimeout(function() {
        const flashMessages = document.querySelector('.flash-messages'); // Seleciona mensagens temporárias
        if (flashMessages) {
            flashMessages.style.opacity = '0'; // Aplica efeito de fade-out (sumir visualmente)
            setTimeout(function() {
                flashMessages.remove(); // Remove o elemento da página
            }, 500); // Depois de meio segundo (animação concluída)
        }
    }, 5000); // Espera 5 segundos após o carregamento da página
});

// Função para abrir o modal de edição e preencher os campos com os dados da tarefa
function openEditModal(id, nome, descricao, imagem) {
    document.getElementById('editTarefaId').value = id;           // Define o ID da tarefa no campo oculto
    document.getElementById('editNome').value = nome;             // Preenche o campo "Nome" com o valor passado
    document.getElementById('editDescricao').value = descricao;   // Preenche o campo "Descrição" com o valor passado
    
    const modal = document.getElementById('editTarefaModal');     // Seleciona o modal de edição
    modal.style.display = 'block';                                // Exibe o modal (mostra na tela)
}

// Função para fechar o modal de edição
function closeEditModal() {
    const modal = document.getElementById('editTarefaModal');     // Seleciona o modal de edição
    modal.style.display = 'none';                                 // Oculta o modal (remove da tela)
}

// Fecha o modal de edição ao clicar fora do conteúdo do modal
window.onclick = function(event) {
    const modal = document.getElementById('editTarefaModal');     // Seleciona o modal de edição
    if (event.target == modal) {                                  // Verifica se o clique foi fora do conteúdo
        modal.style.display = 'none';                             // Fecha o modal
    }
}

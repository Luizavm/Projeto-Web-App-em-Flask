# Importa os módulos necessários do Flask, sistema de arquivos, e manipulação de arquivos CSV
from flask import Flask, render_template, redirect, flash, request, url_for
import os
from werkzeug.utils import secure_filename
import csv

# Cria a aplicação Flask
app = Flask(__name__)

# Caminho para o arquivo CSV onde as tarefas serão salvas
csv_path = "banco_arquivo.csv"

# Define uma chave secreta para uso com sessões e mensagens flash
app.secret_key = os.urandom(24).hex()

# Dicionário para armazenar informações globais do sistema
context = {}
context["logo"] = "img/logo.png"  # Caminho do logo exibido no site

# Dicionário que armazena as tarefas em memória
tarefas = {}
tarefas[1] = {
    "nome": "Bem-vindo!",
    "descricao": "Aqui você pode editar e adicionar tarefas, conseguindo modificar até imagens ou deixar sem nenhuma! Na página de deletar você consegue excluir as tarefas já feitas! Aproveite!",
    "imagem": "img/logo.png"
}

# Função que salva as tarefas no arquivo CSV
def salvar_tarefas_csv():
    with open(csv_path, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["id", "nome", "descricao", "imagem"])  # Cabeçalhos
        for id, tarefa in tarefas.items():
            writer.writerow([id, tarefa["nome"], tarefa["descricao"], tarefa["imagem"]])  # Dados

# Rota da página inicial
@app.route('/')
def homepage():
    context["Inicio"] = "img/inicio.png"
    context["Titulo"] = "Turbo Task"
    context["Texto"] = '''
    Seja bem-vindo ao Turbo Task! Agora você pode organizar e gerenciar suas tarefas sem esforço, é muito fácil!'''
    return render_template("homepage.html", **context)

# Rota que exibe as tarefas
@app.route('/tarefa')
def tarefa():
    context["tarefas"] = tarefas  # Passa as tarefas para o template
    return render_template("tarefa.html", **context)

# Rota que exibe a página para deletar tarefas
@app.route('/del_tarefa')
def del_tarefa():
    context["tarefas"] = tarefas
    return render_template("del_tarefa.html", **context)

# Rota que processa o formulário de exclusão de tarefas
@app.route('/excluir_tarefas', methods=['POST'])
def excluir_tarefas():
    tarefas_ids = request.form.getlist('tarefas_ids')  # Lista de IDs selecionados

    if not tarefas_ids:
        flash('Nenhuma tarefa selecionada para exclusão.', 'warning')
        return redirect(url_for('del_tarefa'))

    try:
        tarefas_ids = [int(id) for id in tarefas_ids]  # Converte os IDs para inteiros
        count = 0

        for id in tarefas_ids:
            if id in tarefas:
                tarefas.pop(id)  # Remove a tarefa
                count += 1

        if count > 0:
            salvar_tarefas_csv()
            flash(f'{count} Tarefa(s) excluída(s) com sucesso!', 'success')
        else:
            flash('Nenhuma das tarefas selecionadas foi encontrada.', 'info')

    except Exception as e:
        flash(f'Erro ao excluir tarefas: {str(e)}', 'error')

    return redirect(url_for('del_tarefa'))

# Rota que exibe o formulário para adicionar uma nova tarefa
@app.route('/add_tarefa_form')
def add_tarefa_form():
    return render_template('add_tarefa.html',**context)

# Rota que processa o formulário de adicionar tarefa
@app.route('/add_tarefa', methods=['POST'])
def add_tarefa():
    next_id = max(tarefas.keys()) + 1 if tarefas else 1  # Gera novo ID

    nome = request.form['nome']
    descricao = request.form['descricao']

    imagem = request.files['imagem']
    if imagem:
        filename = secure_filename(imagem.filename)  # Garante um nome de arquivo seguro
        save_path = os.path.join('static/img', filename)
        imagem.save(save_path)  # Salva o arquivo de imagem
        imagem_path = f'img/{filename}'
    else:
        imagem_path = None  # Se não houver imagem, define como None

    # Adiciona a nova tarefa ao dicionário
    tarefas[next_id] = {
        "nome": nome,
        "descricao": descricao,
        "imagem": imagem_path
    }

    salvar_tarefas_csv()  # Salva no arquivo CSV
    return redirect(url_for('tarefa'))  # Redireciona para a página de tarefas

# Rota que processa a edição de uma tarefa existente
@app.route('/up_tarefa', methods=['POST'])
def up_tarefa():
    tarefa_id = request.form.get('id')
    nome = request.form.get('nome')
    descricao = request.form.get('descricao')
    imagem = request.files.get('imagem')

    # Atualiza a tarefa no dicionário
    tarefas[int(tarefa_id)] = {
        "nome": nome,
        "descricao": descricao,
        "imagem": f"img/{imagem.filename}" if imagem else tarefas[int(tarefa_id)]['imagem']
    }

    # Se uma nova imagem foi enviada, salva-a
    if imagem:
        imagem.save(os.path.join('static/img', imagem.filename))

    salvar_tarefas_csv()
    return redirect(url_for('tarefa'))

# Executa o servidor Flask em modo debug e acessível pela rede
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
